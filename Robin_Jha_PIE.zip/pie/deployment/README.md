Launching docker containers on the Mesos cluster using Marathon:

For the spark cluster we need to deploy master and slaves. This folder contains configuration template and script to launch them. 

ml-master : configuration templates and scripts for Spark Master
ml-slaves : configuration templates and scripts for Spark slaves

More details on the usage of Marathon API can be found here : http://mesosphere.github.io/marathon/docs/rest-api.html


