DC/OS vagrant on coreos

Build on top of coreos-vagrant project this vagrant file follows the DC/OS install instructions from : https://dcos.io/docs/1.8/administration/installing/custom/advanced/

System Requirements:

1. Vagrant
2. Minimum 6G RAM (very conservative)
3. 3 Cores 

This config will create a minimum 3 machines 

1. Bootstrap server
2. Mesos-master node
3. Mesos-agent nodes

Setup Instructions:

1. git clone git@github.com:robinjha/pie.git
2. cd pie/dcos-coreos
3. Edit the Vagrantfile if you want to increase the number of agent with the variable 
	$num_agent = 3 
4. vagrant up
5. Related IP's
	bootstrap server = 172.17.8.100
        mesos master     = 172.17.8.101
        agent 		 = 172.17.8.102
6. Hit the ip https://172.17.8.101 to use the SSO and sign on.	

