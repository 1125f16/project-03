package com.ml.pie.common;

import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.SparkConf;

public class PieCluster {

    public SparkConf spconf;
    public JavaSparkContext spcontext;
    public String clusterEndPoint;

    public PieCluster(String master, String appName, boolean cliRequired) {

        // Configure the master
        clusterEndPoint = master;
        spconf = new SparkConf();
        spconf.setAppName(appName);
        spcontext = new JavaSparkContext(spconf);

        if(cliRequired) {
            String homeDir = System.getProperty("user.home");
            String[] jars = {homeDir + ""};
            spconf.setMaster(clusterEndPoint).setJars(jars);
        }
    }
    public void shutdown() {
        spcontext.close();
    }
}
