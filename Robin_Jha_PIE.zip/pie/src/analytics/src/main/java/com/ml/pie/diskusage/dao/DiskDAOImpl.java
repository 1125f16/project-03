package com.ml.pie.diskusage.dao;


import com.ml.pie.common.PiePredictionResultDB;
import com.ml.pie.common.PieException;
import org.apache.log4j.Logger;
import org.hibernate.*;

/**
 * Created by robin on 11/17/16.
 */

public class DiskDAOImpl implements DiskDAO {

    private static final Logger logger = Logger.getLogger(DiskDAOImpl.class);
    private static SessionFactory sessionFactory;

    static {
        try {
            sessionFactory = PiePredictionResultDB.setHibernateConfig("hibernateconfig.cfg.xml");
        } catch (Throwable e) {
            logger.error("Throwable: " + e.getMessage());
        }
    }

    /**
     * updates or saves the entry into Prediction DB
     * @param entity
     * @param <T>
     * @throws PieException
     */
    public <T> void updateOrSave(T entity) throws PieException {
        Session session = null;
        Transaction tx = null;
        try {
            session = sessionFactory.getCurrentSession();
            tx = session.beginTransaction();
            session.saveOrUpdate(entity);
            tx.commit();
        } catch (HibernateException e) {
            logger.error(e.getMessage());
            PiePredictionResultDB.catchException(tx, e);
        } finally {
            PiePredictionResultDB.closeSession(session);
        }
    }

}
