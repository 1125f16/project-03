package com.ml.pie.diskusage.model;

import java.io.Serializable;

public class DiskAttributes implements Serializable {

	private static final long serialVersionUID = 1L;
	String diskName;
	double value;
	long timestamp;

	public String getDiskName() {

		return diskName;
	}

	public void setDiskName(String diskName) {

		this.diskName = diskName;
	}

	public long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}

	public double getValue() {

	    return value;
	}

	public void setValue(double value) {

		this.value = value;
	}

	@Override
	public String toString() {

		return String.format("%s %d %f", diskName, timestamp, value);
	}
}
