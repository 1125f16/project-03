package com.ml.pie.common;

import java.text.SimpleDateFormat;
import java.util.Enumeration;
import java.util.Properties;
import java.util.ResourceBundle;


public class PieConstants {

	public static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	public static final String sparkMaster;
	public static final String datasourceURL;
	public static final Properties props;
	
	static {
		ResourceBundle bundle = ResourceBundle.getBundle("pie");
		props = new Properties();
		Enumeration<String> keys = bundle.getKeys();
		while (keys.hasMoreElements()) {
			String key = keys.nextElement();
			props.put(key, bundle.getString(key));
		}
		sparkMaster = props.getProperty("spark.master");
		datasourceURL = props.getProperty("datasource.url");
	}
}
