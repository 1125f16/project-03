package com.ml.pie.run;

import com.ml.pie.diskusage.DiskUsageMain;
import com.ml.pie.common.PieCluster;


/**
 * Entrypoint/ Main class for PIE
 */
public class PieExecutor {

	public static void main(String[] args) {

		String appName = "PIE";
		String sparkMaster = "spark://pie-mlmaster.mesos:7077";


        boolean cliRequired = (args.length == 1 && args[0].equals("cli"));
        PieCluster cluster = new PieCluster(sparkMaster, appName, cliRequired);

        if (args[0].equals("DiskUsage")) {
            System.out.println("Running PIE Job for predicting : " + args[0]);
            System.out.println("====================================================");
            DiskUsageMain predictor = new DiskUsageMain(cluster);
            predictor.run();
        } else {
            System.out.println("Unknown Job : " + args[0]);
        }
		cluster.shutdown();
		System.exit(0);
	}
}
