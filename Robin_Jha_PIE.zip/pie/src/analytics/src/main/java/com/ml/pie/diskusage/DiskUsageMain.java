package com.ml.pie.diskusage;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import com.ml.pie.diskusage.dao.DiskDAO;
import com.ml.pie.diskusage.dao.DiskDAOImpl;
import com.ml.pie.common.PieException;
import com.ml.pie.common.PieCluster;

import com.ml.pie.diskusage.entities.DiskUsage;
import org.apache.spark.api.java.JavaSparkContext;
import com.ml.pie.common.PieBase;


public class DiskUsageMain extends PieBase {

    PieCluster scluster;

    public DiskUsageMain(PieCluster cluster)  {
        super("DiskUsage Predictor");
        scluster = cluster;
    }

    public void run() {
        try {
            findDisksGettingFull(scluster.spcontext);
        } catch(PieException e) {
            e.printStackTrace();
        }
    }

    public static void findDisksGettingFull(JavaSparkContext sc) throws PieException {
        List<DiskUsage> records = DiskUsagePredictor.findDisksGettingFullAndUpdateDatabase(sc, 0.001);
        try {
            FileWriter resultFile = new FileWriter("/tmp/disk_prediction_results.txt");

            DiskDAO ddao = new DiskDAOImpl();
            for(DiskUsage r: records){
                ddao.updateOrSave(r);
                resultFile.write(r.toString() + "\n");
            }

        } catch (IOException e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
        }
    }
}











