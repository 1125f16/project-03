package com.ml.pie.diskusage.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.ml.pie.common.PieConstants;

@Entity
@Table(name = "disk_usage")
public class DiskUsage {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)	
	@Column(name = "id")	
	private int id;
	@Column(name = "host_ip")
	private String hostIp;
	@Column(name = "disk_name")
	private String diskName;
	/**
	 * current disk usage in %
	 */
	@Column(name = "currentusage")
	private double usage;
	/**
	 * speed in % per hour
	 */
	@Column(name = "speed")
	private double speed;
	/**
	 * record time stamp 
	 */
	@Column(name = "datetime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dateTime;
	/**
	 * time stamp when disk will become full 
	 */
	@Column(name = "getsfull")
	@Temporal(TemporalType.TIMESTAMP)
	private Date getsFull;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getHostIp() {
		return hostIp;
	}
	public void setHostIp(String hostIp) {
		this.hostIp = hostIp;
	}
	public String getDiskName() {
		return diskName;
	}
	public void setDiskName(String diskName) {
		this.diskName = diskName;
	}
	public double getUsage() {
		return usage;
	}
	public void setUsage(double usage) {
		this.usage = usage;
	}
	public double getSpeed() {
		return speed;
	}
	public void setSpeed(double speed) {
		this.speed = speed;
	}
	public Date getDateTime() {
		return dateTime;
	}
	public void setDateTime(Date dateTime) {
		this.dateTime = dateTime;
	}
	public Date getGetsFull() {
		return getsFull;
	}
	public void setGetsFull(Date getsFull) {
		this.getsFull = getsFull;
	}
	
	@Override
	public String toString() { 
		return String.format("HostIP: %s DiskName: %s usage %f speed %f at %s gets full %s", hostIp, diskName, usage, speed, PieConstants.sdf.format(dateTime), PieConstants.sdf.format(getsFull));
	}
}
