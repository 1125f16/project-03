package com.ml.pie.common;

import org.hibernate.Session;
import org.hibernate.SessionException;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

/**
 * manages sessions to prediction database
 * and implements other helper function
 */
public class PiePredictionResultDB {

    /**
     * closes the given session
     * @param session
     */
    public static void closeSession(Session session){
        if (session != null && session.isOpen())
            try {
                session.close();
            } catch (SessionException e) {
                e.printStackTrace();
            }
    }

    public static void catchException(Transaction tx,Exception e) throws PieException {
        if (tx != null && tx.isActive())
            tx.rollback();
        throw new PieException("HibernateException: " + e.getMessage());
    }

    /**
     * sets hibernate config given a config file
     * @param filename
     * @return sessionfactory
     */
    public static SessionFactory setHibernateConfig(String filename){


        Configuration config = new Configuration().configure(filename);
        StandardServiceRegistryBuilder serviceRegistryBuilder =
                new StandardServiceRegistryBuilder();
        serviceRegistryBuilder.applySettings(config.getProperties());
        ServiceRegistry serviceRegistry = serviceRegistryBuilder.build();
        return config.buildSessionFactory(serviceRegistry);
    }
}