package com.ml.pie.diskusage;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.Date;
import java.util.Iterator;

import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import com.ml.pie.diskusage.db.DataAccessor;
import com.ml.pie.diskusage.entities.DiskUsage;
import com.ml.pie.diskusage.model.DiskAttributes;
import com.ml.pie.common.PieException;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.ml.feature.Bucketizer;
import org.apache.spark.ml.regression.LinearRegression;
import org.apache.spark.ml.regression.LinearRegressionModel;
import org.apache.spark.mllib.linalg.VectorUDT;
import org.apache.spark.mllib.linalg.Vectors;

/**
 * This module does the disk usage prediction.
 */

public class DiskUsagePredictor {
	private static final Logger logger = Logger.getLogger(DiskUsagePredictor.class);

	/**
	 * ﻿﻿Parameter for mapping continuous features into buckets. With n+1 splits, there are n buckets.
	 * A bucket defined by splits x,y holds values in the range [x,y) except the last bucket, which also includes y.
	 * Splits should be strictly increasing.
	 * @param from
	 * @param to
	 * @param numberOfBuckets
	 * @return
	 */
	public static double[] defineSplits(double from, double to, int numberOfBuckets) {
		if(from >= to)
			return null;
		double[] splits = new double[numberOfBuckets + 1];
		splits[0] = Double.NEGATIVE_INFINITY;
		splits[numberOfBuckets] = Double.POSITIVE_INFINITY;
		splits[1] = from;
		double step = (to - from) / numberOfBuckets;
		for (int i = 1; i < numberOfBuckets - 1; i++)
			splits[i + 1] = splits[i] + step;
		return splits;
	}

	/**
	 * predicts when disks will get full and writes to the prediction database
	 * @param sc
	 * @param criticalSpeed
	 * @return
	 * @throws PieException
	 */
	public static List<DiskUsage> findDisksGettingFullAndUpdateDatabase(JavaSparkContext sc, double criticalSpeed) throws PieException {
		List<DiskUsage> diskusageRecords = new ArrayList<DiskUsage>();
		int numOfBuckets = 5;
		double min, max,a, b, speed;
		double[] splits;
		long full;
		String diskUsagePercTempDB = "diskUsagePercentReadings";
		String hostIp;
		try {
			DataAccessor historyInfo = new DataAccessor();
			Set<String> allHostIPS = historyInfo.getAllHostIps();
			//logger.info(String.format("Found hosts %d", allHostIPS.size()));
            logger.error(String.format("Found hosts %d", allHostIPS.size()));//R :
			if (allHostIPS.size() == 0) {
				logger.error("No records exist for any hosts...exiting..!!");
				return null;
			}
			Iterator<String> it = allHostIPS.iterator();

			while (it.hasNext()) { // loops through the list of available IPS
				hostIp = it.next();
				logger.error("========================================================");//R:
				SQLContext sql = new SQLContext(sc);
				List<DiskAttributes> diskUsagePercentReadings = historyInfo.getDiskReadings(hostIp);
				JavaRDD<DiskAttributes> diskUsagePercentReadingsRDD = sc.parallelize(diskUsagePercentReadings);
				DataFrame diskUsagePercentReadingDF = sql.createDataFrame(diskUsagePercentReadingsRDD, DiskAttributes.class);
				diskUsagePercentReadingDF.registerTempTable(diskUsagePercTempDB);
				DataFrame diskNamesDF = sql.sql("SELECT diskName, min(timestamp)*1.E-3 as min, max(timestamp)*1.E-3 as max  FROM " + diskUsagePercTempDB + " GROUP BY diskName");
                //logger.error("diskNamesDF Collection: " + diskNamesDF.toString()); //R:
				logger.error("diskNamesDF collection: =============================");//R
				diskNamesDF.show();//R
				String queryFormat = "SELECT (timestamp*1.E-3) as date,value FROM %s WHERE diskName='%s'";
				for (Row row : diskNamesDF.collect()) {
					String diskName = row.getString(0);
					logger.error(String.format("processing %s:%s", hostIp, diskName));//R
					min = row.getDouble(1);
					max = row.getDouble(2);
					if(max - min < 3600 ) { // if range is less than an hour there is not enough data, continue
						logger.error("Historic data not enough on  " + diskName + " " + hostIp);
						continue;
					}
					splits = defineSplits((long) min, (long) max, numOfBuckets);
					DataFrame diskUsagePercentDF = sql.sql(String.format(queryFormat, diskUsagePercTempDB, diskName));
					///logger.error("PERCENT DF -----");
					///diskUsagePercentDF.show(); //R
					Bucketizer bucketizer = new Bucketizer().setInputCol("date").setOutputCol("bucketedFeatures").setSplits(splits);



                }
				logger.error("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
			}
			
		} catch (PieException e) {
			e.printStackTrace();
			throw new PieException(e.getClass().getName() + ": " + e.getMessage());
		} 
		return diskusageRecords;
	}

}
