package com.ml.pie.diskusage.dao;

import com.ml.pie.common.PieException;

/**
 * interface for DiskDAO
 */
public interface DiskDAO {
    <T> void updateOrSave(T entity) throws PieException;

}
