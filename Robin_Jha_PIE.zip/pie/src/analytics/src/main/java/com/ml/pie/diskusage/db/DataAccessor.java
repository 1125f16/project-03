package com.ml.pie.diskusage.db;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import com.ml.pie.diskusage.model.DiskAttributes;
import com.ml.pie.common.PieConstants;
import com.ml.pie.common.PieException;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import io.searchbox.client.JestClient;
import io.searchbox.client.JestClientFactory;
import io.searchbox.client.JestResult;
import io.searchbox.client.config.HttpClientConfig;
import io.searchbox.core.Search;
import io.searchbox.core.SearchResult;
import io.searchbox.core.search.aggregation.TermsAggregation;
import io.searchbox.core.search.aggregation.TermsAggregation.Entry;
import io.searchbox.indices.aliases.GetAliases;
import io.searchbox.params.Parameters;

/**
 * This module is used to get historical usage data from the datasource
 * for all IPs in the cluster.
 */
public class DataAccessor {
	private static final Logger logger = Logger.getLogger(DataAccessor.class);

	public enum MEASURE_TYPE {
		HostDiskUsePerc
	}

	private static final int connTimeout = 30000; //millisecond
	private static final int readTimeout = 60000; //millisecond
	private static final JestClient client;
	public static final SimpleDateFormat timestampFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");

	static {
		logger.setLevel(Level.DEBUG);
		JestClientFactory factory = new JestClientFactory();
		factory.setHttpClientConfig(new HttpClientConfig.Builder(PieConstants.datasourceURL).multiThreaded(true)
				.connTimeout(connTimeout).readTimeout(readTimeout).build());
		client = factory.getObject();
	}

	/**
	 * returns a set of indices given a prefix
	 * @param - index prefix
	 * @return
	 * @throws PieException
	 */
	private static Set<String> getIndicesSet(String prefix) throws PieException {
		Set<String> indices = new HashSet<String>();
		GetAliases aliases = new GetAliases.Builder().build();
		try {
			JestResult result = client.execute(aliases);
			if (prefix == null)
				for (java.util.Map.Entry<String, JsonElement> entry : result.getJsonObject().entrySet())
					indices.add(entry.getKey());
			else
				for (java.util.Map.Entry<String, JsonElement> entry : result.getJsonObject().entrySet()) {
					String index = entry.getKey();
					if (index.startsWith(prefix))
						indices.add(index);
				}
		} catch (IOException e) {
			throw new PieException(e.getClass().getName() + ": " + e.getMessage());
		}
		return indices;
	}

	private static Set<String> getHostIps(String esIndex, String esType) throws PieException {
		Set<String> hostIps = new HashSet<String>();
		String guery = "{\"query\":{\"match_all\":{}},\"aggregations\":{\"aggrTag\":{\"terms\":{\"field\":\"hostip\", \"size\":0}}}}";
		Search.Builder searchBuilder = new Search.Builder(guery).addIndex(esIndex).addType(esType);
		try {
			SearchResult result = client.execute(searchBuilder.build());
			TermsAggregation terms = result.getAggregations().getTermsAggregation("aggrTag");
			for (Entry bucket : terms.getBuckets())
				hostIps.add(bucket.getKey());
		} catch (IOException e) {
			throw new PieException(e.getClass().getName() + ": " + e.getMessage());
		}
		return hostIps;
	}


	/**
	 *
	 * @return - set of all host IPs from datasource
	 * @throws PieException
	 */
	public Set<String> getAllHostIps() throws PieException {
		String indexPrefix = "host_stats";
		String esType = "metrics";
		Set<String> hostIps = new HashSet<String>();
		Set<String> esIndices = DataAccessor.getIndicesSet(indexPrefix);
		Set<String> validIndices;
		logger.info(String.format("Found indices %d", esIndices.size()));
		if (esIndices.size() < 2) {
			logger.error("History goes back less than one day. Not enough data to proceed. Quitting ....");
			return null;
		}
		validIndices = DataAccessor.getfirstNelements(esIndices, 9); // initial value 3
		for (String index : validIndices)
			hostIps.addAll(DataAccessor.getHostIps(index, esType));
		return hostIps;
	}


	private static List<DiskAttributes> getDiskReadings(String hostIp, MEASURE_TYPE measureType, String esIndex, String esType, int limit) throws PieException {
		JsonObject source;
		DiskAttributes reading;
		List<DiskAttributes> readings = new ArrayList<DiskAttributes>();
		String gueryFormat = "{\"sort\":[{\"@timestamp\":{\"order\":\"desc\"}}], \"fields\":[\"diskname\", \"value\", \"@timestamp\"], \"query\": { \"bool\": {\"must\":[{\"match\":{\"measure\":\"%s\"}},{\"match\":{\"hostip\":\"%s\"}}]}}}";
		String query = String.format(gueryFormat, measureType.name(), hostIp);
		String details = String.format("%s/%s/_search?size=%d -d '%s'", esIndex, esType, limit, query);
		Search.Builder searchBuilder = new Search.Builder(query).addIndex(esIndex).addType(esType)
				.setParameter("_source", true)
				.setParameter(Parameters.SIZE, limit);
		SearchResult result = null;
		try {
			result = client.execute(searchBuilder.build());
			JsonArray hitsArray = result.getJsonObject().getAsJsonObject("hits").getAsJsonArray("hits");
			for (int i = 0; i < hitsArray.size(); i++) {
				reading = new DiskAttributes();
				source = hitsArray.get(i).getAsJsonObject().getAsJsonObject("_source");
				reading.setDiskName(source.get("diskname").getAsString());
				try {
					reading.setTimestamp(timestampFormat.parse(source.get("@timestamp").getAsString()).getTime());
					reading.setValue(Double.parseDouble(source.get("value").getAsString()));
				} catch (NumberFormatException | ParseException e) {
					logger.error(e.getClass().getName() + ": " + e.getMessage() + " while running " + details);
					logger.error(source);
					continue;
				}
				if (reading.getValue() == 0.0d || reading.getDiskName().length() == 0) {
					continue;
				}
				readings.add(reading);
			}
		} catch (IOException e) {
			throw new PieException(e.getClass().getName() + ": " + e.getMessage() + "\n while running " + details);
		} catch (Throwable ex) {
			logger.error("Error writing ", ex);
		}
		return readings;
	}

	public List<DiskAttributes> getDiskReadings(String hostIp) throws PieException {
		int limit = 100; // getting 10 records to begin with
		String esType = "metrics";
		String indexPrefix = "host_stats";
		Set<String> esIndices = DataAccessor.getIndicesSet(indexPrefix);
		Set<String> validIndices;
		if (esIndices.size() < 2) {
			throw new PieException("History depth is less than one day. Quitting.");
		}
		validIndices = DataAccessor.getfirstNelements(esIndices, 3);

		List<DiskAttributes> perCentReadings = new ArrayList<>();
		List<DiskAttributes> readings;
		for(String esIndex : validIndices) {
			readings = DataAccessor.getDiskReadings(hostIp, DataAccessor.MEASURE_TYPE.HostDiskUsePerc, esIndex, esType, limit);
			perCentReadings.addAll(readings);
		}
		return perCentReadings;
	}


	/**
	 * returns the set of first N elements
	 * @param elements
	 * @param N - number of elements wanted
	 * @return - set of first N elements given a set
	 */
    public static Set<String> getfirstNelements(Set<String> elements, int N) {
        Set<String> newlist = new HashSet<String>();;
        String [] elemlist  = elements.toArray(new String[elements.size()]);
        for(int i=0; i < N; i++) {
            newlist.add(elemlist[i]);
        }
        return newlist;
    }

}
