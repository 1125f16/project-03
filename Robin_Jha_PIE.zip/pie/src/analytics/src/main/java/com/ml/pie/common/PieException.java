package com.ml.pie.common;

public class PieException extends Exception {
	private static final long serialVersionUID = 1L;
	public PieException(String msg) {
		super(msg);
	}
}
