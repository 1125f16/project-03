package com.ml.pie.common;


public class PieBase {

    String jobName;
    public PieBase(String name) {
        setJobName(name);
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

}
